class ImageNotFoundException(Exception):
    pass