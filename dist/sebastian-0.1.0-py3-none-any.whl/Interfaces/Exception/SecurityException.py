class SecurityException(Exception):
    pass