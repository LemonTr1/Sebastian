class JsonResolverError(Exception):
    pass