from agents import Agent, Runner
from agents.sandbox import SandboxAgent
from src.Interfaces.Capabilities.BrainCapabilities.Capabilities import Capabilities, AGENT_CAPABILITIES
from src.Modules.FileModules.FileAgentRunner import file_agent_runner
from src.Modules.WebModules.WebAgentRunner import web_agent_runner
from src.Modules.CodeModules.CodeAgentRunner import code_agent_runner
from src.Modules.MemoryModules.MemoryAgentRunner import memory_agent_runner

class CapabilityGuard:
    #权限检查
    @staticmethod
    def check(agent_name: str, required_caps: Capabilities) -> None:
        allowed = AGENT_CAPABILITIES.get(agent_name)
        if allowed != required_caps:
            raise PermissionError(
                f"[权限不足] 当前Agent：{agent_name} 权限为 {allowed.name}，"
                f"实际需要权限：{required_caps.name}"
            )

    @staticmethod
    async def run(
            agent: Agent | SandboxAgent,
            agent_name: str,
            task: str,
            required_caps: Capabilities,
            max_turns: int = 20,
            path: str = "None"
    )->str:
        CapabilityGuard.check(agent_name, required_caps)
        if agent_name == "Code_Agent":
            return await code_agent_runner(agent, task, max_turns, path)
        elif agent_name == "Web_Agent":
            return await web_agent_runner(agent, task, max_turns)
        elif agent_name == "File_Agent":
            return await file_agent_runner(agent, task, max_turns)
        elif agent_name == "Memory_Agent":
            return await memory_agent_runner(agent, task, max_turns)
        raise Exception("Agent启动运行失败")
