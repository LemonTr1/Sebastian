from src.Interfaces.Capabilities.BrainCapabilities.Capabilities import Capabilities
from agents import Runner, ModelSettings, Agent
from src.Interfaces.Exception.SecurityException import SecurityException
from src.Models.models import get_model
import re

agent = Agent(
        name="Judger",
        model_settings=ModelSettings(
            temperature=0.0,
        ),
        model=get_model(),
        instructions=(
        "You are an intent classifier. Your task is to classify the user's command "
        "into exactly one of the following labels. Output ONLY the label text, "
        "no quotes, no explanations, no markdown, no punctuation.\n\n"

        "=== CRITICAL PRIORITY RULE ===\n"
        "When a command involves BOTH code/content AND file system operations, "
        "use this order of precedence:\n"
        "1. EXECUTE/RUN/CALL EXCEPTION: If the PRIMARY VERB is execute, run, call, invoke, "
        "perform, or their Chinese equivalents (执行/运行/调用/启动), and the target is an "
        "EXISTING code file, script, project file, or program → classify as Code. "
        "The file is merely the CARRIER of the code; the real intent is execution, "
        "NOT file management.\n"
        "2. FILE MANAGEMENT: If the operation involves creating, reading (for inspection/copying), "
        "writing, saving, editing, deleting, moving, copying, compressing, decompressing, "
        "changing permissions, or searching files/directories → classify as File. "
        "INCLUDES: saving code to a file, writing a script to disk, creating .py/.js/.md files, "
        "reading source code from a file for modification. If the intent is to MANIPULATE the file "
        "itself, THIS IS ALWAYS THE ANSWER.\n\n"

        "=== LABEL DEFINITIONS ===\n"
        "- File: File SYSTEM MANAGEMENT. Creating/reading-for-copying/writing/deleting/moving/copying "
        "files or directories, compressing/decompressing, changing permissions, searching files. "
        "INCLUDES: saving code to a file, writing a script to disk, reading source code for "
        "modification, creating .py/.js/.md files. ONLY when the file ITSELF is the target of "
        "management, not when it is merely being executed.\n"
        "- Code: PURE code logic OR EXECUTION of existing code. Running scripts, executing code files, execute command in the terminal"
        "debugging, algorithm design, math calculation, bash command"
        "calling/invoking existing programs or scripts. INCLUDES: 'execute this code file', "
        "'run the project file', 'perform this script', 'call main.py', 'execute this command in the terminal'.\n"
        "- Web: web search, download, real-time info query, URL access, API calls, operate the browser\n"
        "- Memory: local knowledge base operations: storing documents/text into ChromaDB, "
        "semantic search/retrieval from ChromaDB, listing/deleting collections, "
        "RAG (Retrieval-Augmented Generation), embedding text, managing vector database. "
        "INCLUDES: '记住这段文本', '搜索我的知识库', '存储这段内容', '查询本地记忆', "
        "'从知识库中检索', '列出所有集合', '删除集合'. "
        "If the user wants to SAVE, STORE, or REMEMBER text/content for later retrieval, "
        "or SEARCH/QUERY previously stored content → Memory.\n\n"

        "=== EXAMPLES ===\n"
        "执行这个代码文件 → Code (primary intent is execution, file is only the carrier)\n"
        "执行这个项目文件 → Code (running the project, not managing its files)\n"
        "运行 app.py → Code (executing an existing script)\n"
        "调用 test.py → Code (invoking existing code)\n"
        "Write a Python script and save it to app.py → File (creating/writing file)\n"
        "Write a Python script to calculate primes → Code (no file path, pure logic)\n"
        "Create main.py → File (file creation)\n"
        "Read main.py → File (reading file content for inspection)\n"
        "Edit the code in main.py → File (editing a file)\n"
        "Run the code → Code (execution, no file operation)\n"
        "Debug this function → Code (debugging logic, no file path)\n"
        "Download a file from web → Web\n"
        "操作浏览器打开小红书 -> Web(operate the browser)\n"

        "If none match, output exactly: None"
        )
    )

#所有可能的恶意命令
DANGEROUS_PATTERNS = [
    r"rm\s+-rf\s+[/\\]",
    r"mkfs\.\w+",
    r":\(\)\{\s*:\|:\&\};:",
]

def security_guard(command: str) -> None:
    for p in DANGEROUS_PATTERNS:
        if re.search(p, command, re.I):
            raise SecurityException("高危操作被系统拦截")

async def infer_capabilities(command: str):
    #检查命令安全性
    security_guard(command)
    try:
        result = await Runner.run(agent, input=command)
    except SecurityException as e:
        raise SecurityException("Judger Agent出现故障，鉴权失败，指令无法下发")
    context = result.final_output
    if context == "File":
        cap =  Capabilities.FILE_EXECUTE
    elif context == "Code":
        cap =  Capabilities.CODE_EXECUTE
    elif context == "Web":
        cap =  Capabilities.WEB_EXECUTE
    elif context == "Memory":
        cap =  Capabilities.MEMORY_EXECUTE
    else:
        raise PermissionError(f"Unexpected output from judger agent: {context}")

    return cap


