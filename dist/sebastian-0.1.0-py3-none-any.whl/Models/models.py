import os
os.environ['http_proxy'] = ''
os.environ['https_proxy'] = ''
os.environ['all_proxy'] = ''
from dotenv import load_dotenv
load_dotenv()
from agents import set_tracing_disabled
from agents.extensions.models.litellm_model import LitellmModel

#关闭追踪，DeepSeek不支持
set_tracing_disabled(True)

#将DeepSeek封装成Agents SDK可用的模型对象
deepseek_model = LitellmModel(
    model = str(os.getenv("DEEPSEEK_MODEL")),
    api_key=os.getenv("DEEPSEEK_API_KEY")
)

def get_model():
    return deepseek_model