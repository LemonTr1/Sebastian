import asyncio
from agents import SQLiteSession

def _load_session():
    return SQLiteSession("web_conversation")

_SESSION = _load_session()

_web_session_lock = asyncio.Lock()

def get_web_session():
    return _SESSION

def get_web_session_lock():
    """返回模块级锁，供外部包裹 Runner.run 使用"""
    return _web_session_lock