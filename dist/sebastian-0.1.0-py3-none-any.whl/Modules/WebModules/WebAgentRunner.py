import json
import typer
from agents import Agent, Runner
from src.Modules.WebModules.WebSession import get_web_session, get_web_session_lock

async def web_agent_runner(agent: Agent, task: str, max_turns: int):
    async with get_web_session_lock():
        session = get_web_session()
        result = await Runner.run(agent, input=task, max_turns=max_turns, session=session)
        while result.interruptions:
            state = result.to_state()

            for interruption in result.interruptions:
                args = json.loads(interruption.arguments)
                if interruption.name == "download_file":
                    url = args.get("url")
                    save_dir = args.get("save_dir")
                    confirmed = typer.confirm(typer.style(f"[Warn]确定下载 {url} 的资源到 {save_dir} 目录下吗？", fg=typer.colors.YELLOW))
                    if confirmed:
                        state.approve(interruption, always_approve=False)
                    else:
                        state.reject(interruption, rejection_message="用户拒绝执行本次操作，立即停止并向上级Agent反馈")

            result = await Runner.run(agent, state)

        return result.final_output