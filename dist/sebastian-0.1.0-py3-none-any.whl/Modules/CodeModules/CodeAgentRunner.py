import json
from agents import Agent, Runner, RunConfig
from agents.run_config import SandboxRunConfig
from agents.sandbox import Manifest, SandboxPathGrant
import os
import typer
from agents.sandbox.entries import LocalDir, File
from src.Interfaces.Docker.EnsureDocker import ensure_image
from src.Interfaces.Exception.ImageNotFoundException import ImageNotFoundException
from src.Modules.CodeModules.CodeSession import get_code_session_lock, get_code_session
from pathlib import Path
from src.Modules.CodeModules.SandboxSessionFactory import SandboxSessionFactory

WORKSPACE = Path.home()

async def code_agent_runner(agent: Agent, task: str, max_turns: int, path: str):
    # 对CodeAgent共享Session缓冲区读取必须互斥，所以实际上还是只能串行执行Shell命令或代码
    async with get_code_session_lock():
        session = get_code_session()
        # 检查本地镜像是否正常运行
        try:
            ensure_image("sebastian:local")
        except ImageNotFoundException as e:
            raise ImageNotFoundException(str(e))
        # 挂载再运行
        manifest = Manifest()
        if path != "None":
            if os.path.isdir(path):
                manifest = Manifest(
                    # 额外授权目录
                    extra_path_grants=(
                        SandboxPathGrant(path=str(path), read_only=True),
                    ),
                    entries={
                        # 挂载点
                        f"{str(Path(path).name)}": LocalDir(src=Path(path)),
                    }
                )
            else:
                manifest = Manifest(
                    entries={
                        f"{str(Path(path).name)}": File(content=Path(path).read_bytes()),
                    }
                )
        run_session = await SandboxSessionFactory.get_session(manifest)
        run_config = RunConfig(
                    sandbox=SandboxRunConfig(
                        session=run_session
                    )
                )
        typer.echo(typer.style(f"[执行中]正在沙箱中执行代码...", fg=typer.colors.WHITE))
        async with run_session:
            result = await Runner.run(
                agent,
                input=task,
                max_turns=max_turns,
                session=session,
                run_config=run_config
            )

            while result.interruptions:
                state = result.to_state()

                for interruption in result.interruptions:
                    args = json.loads(interruption.arguments)
                    if interruption.name == "mount":
                        dst = args.get("dst")
                        confirmed = typer.confirm(typer.style(f"[Warn]确定将沙箱内产出挂载到{dst}吗？",fg=typer.colors.YELLOW))
                        if confirmed:
                            state.approve(interruption, always_approve=False)
                        else:
                            state.reject(interruption,
                            rejection_message="用户拒绝执行本次操作，立即停止并向上级Agent反馈")
                result = await Runner.run(agent, state, run_config=run_config)

            return result.final_output