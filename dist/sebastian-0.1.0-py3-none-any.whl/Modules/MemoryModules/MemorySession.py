import asyncio
from agents import SQLiteSession

def _load_session():
    return SQLiteSession("memory_conversation")

_SESSION = _load_session()

_memory_session_lock = asyncio.Lock()

def get_memory_session():
    return _SESSION

def get_memory_session_lock():
    """返回模块级锁，供外部包裹 Runner.run 使用"""
    return _memory_session_lock
