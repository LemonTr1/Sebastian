from agents import Agent, Runner
from src.Modules.MemoryModules.MemorySession import get_memory_session, get_memory_session_lock

async def memory_agent_runner(agent: Agent, task: str, max_turns: int):
    async with get_memory_session_lock():
        session = get_memory_session()
        result = await Runner.run(agent, input=task, max_turns=max_turns, session=session)
        return result.final_output
