from pathlib import Path
import typer
from agents import Agent, Runner
from src.Modules.FileModules.FileSession import get_file_session, get_file_session_lock
import os
import json

async def file_agent_runner(agent: Agent, task: str, max_turns: int):
    async with get_file_session_lock():
        session = get_file_session()
        result = await Runner.run(agent, input=task, max_turns=max_turns, session=session)

        while result.interruptions:
            state = result.to_state()

            for interruption in result.interruptions:
                args = json.loads(interruption.arguments)
                if interruption.name == "rename":
                    src = args.get("src")
                    new_name = args.get("new_name")
                    parent_path = Path(str(src)).parent
                    dst = parent_path / new_name
                    confirmed = typer.confirm(typer.style(f"[Warn]确定将{str(src)}重命名为{str(dst)}吗",fg=typer.colors.YELLOW))
                    if confirmed:
                        state.approve(interruption, always_approve=False)
                    else:
                        state.reject(interruption, rejection_message="用户拒绝执行本次操作，立即停止并向上级Agent反馈")

                elif interruption.name == "rm":
                    path = args.get("path")
                    filename = args.get("filename")
                    path = os.path.abspath(path)
                    file_path = os.path.join(path, filename)
                    confirmed = typer.confirm(typer.style(f"[Warn]确定要删除文件系统对象：{str(file_path)}吗？", fg=typer.colors.YELLOW))
                    if confirmed:
                        if os.path.isdir(file_path):
                            double_confirmed = typer.confirm(typer.style(f"[Warn] '{str(file_path)}' 是目录，删除将清空所有内容，继续吗？", fg=typer.colors.YELLOW))
                            if double_confirmed:
                                state.approve(interruption, always_approve=False)
                            else:
                                state.reject(interruption, rejection_message="用户拒绝执行本次操作，立即停止并向上级Agent反馈")
                        else:
                            state.approve(interruption, always_approve=False)
                    else:
                        state.reject(interruption, rejection_message="用户拒绝执行本次操作，立即停止并向上级Agent反馈")

                elif interruption.name == "edit":
                    path = args.get("path")
                    filename = args.get("filename")
                    path = os.path.abspath(path)
                    file_path = os.path.join(path, filename)
                    confirmed = typer.confirm(typer.style(f"[Warn]你确定要修改文件{str(file_path)}的内容吗", fg=typer.colors.YELLOW))
                    if confirmed:
                        state.approve(interruption, always_approve=False)
                    else:
                        state.reject(interruption, rejection_message="用户拒绝执行本次操作，立即停止并向上级Agent反馈")

                elif interruption.name == "create_file":
                    path = args.get("path")
                    filename = args.get("filename")
                    file_path = os.path.join(path, filename)
                    confirmed = typer.confirm(
                        typer.style(f"[Warn]文件{str(file_path)}已经存在，覆盖会清空内容，确定吗？", fg=typer.colors.YELLOW))
                    if confirmed:
                        state.approve(interruption, always_approve=False)
                    else:
                        state.reject(interruption, rejection_message="用户拒绝执行本次操作，立即停止并向上级Agent反馈")

                elif interruption.name == "safe_move":
                    src = args.get("src")
                    dst = args.get("dst")
                    confirmed = typer.confirm(typer.style(f"[Warn]确定将 {src} 移动至目录 {dst} 下吗？", fg=typer.colors.YELLOW))
                    if confirmed:
                        state.approve(interruption, always_approve=False)
                    else:
                        state.reject(interruption, rejection_message="用户拒绝执行本次操作，立即停止并向上级Agent反馈")

            result = await Runner.run(agent, state)

        return result.final_output