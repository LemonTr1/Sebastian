from agents import SQLiteSession, Runner
from openai.types.responses import ResponseTextDeltaEvent
from src.Agents.BrainAgent import brain_agent
from src.Interfaces.Exception.SecurityException import SecurityException
import os
import typer
from src.Interfaces.UserInfo import UserInfo

async def chat():
    uname = os.getlogin()
    typer.echo(typer.style(f"Welcome {uname}！I'm Sebastian.What can I do for you? [Press 'quit' to exit]", fg=typer.colors.BLUE, bold=True))
    user_session = SQLiteSession(uname)
    while True:
        question = typer.prompt(typer.style(f"\n[{uname}]", fg=typer.colors.GREEN, bold=True))
        if question.lower() in ["quit", "exit", "再见"]:
            typer.echo(typer.style("Bye", fg=typer.colors.BLUE, bold=True))
            raise typer.Exit(code=0)
        try:
            result = Runner.run_streamed(brain_agent, input=question, context=UserInfo(username=uname), session=user_session, max_turns=50)
        except SecurityException as e:
            typer.echo(typer.style(f"Ops！你的输入被安全系统拦截了：{e}", fg=typer.colors.RED, bold=True))
            raise typer.Exit(code=1)
        except Exception as e:
            typer.echo(typer.style(f"Ops！机器人出现故障了：{e}", fg=typer.colors.RED, bold=True))
            raise typer.Exit(code=1)
        typer.echo(typer.style("[Sebastian]: ", fg=typer.colors.BLUE, bold=True), nl=False)
        async for event in result.stream_events():
            if event.type == "raw_response_event" and isinstance(event.data, ResponseTextDeltaEvent):
                delta = event.data.delta
                typer.echo(delta, nl=False)
        typer.echo()