import os
os.environ['http_proxy'] = ''
os.environ['https_proxy'] = ''
os.environ['all_proxy'] = ''
from dotenv import load_dotenv
load_dotenv()
import json
import typer
from agents import function_tool
from src.Tools.Memory_Tools.ChromaManager import get_collection, list_collections, get_client
from sentence_transformers import SentenceTransformer
from pathlib import Path
from huggingface_hub import snapshot_download

HOME = Path.home()
MODEL_DIR = HOME / ".embedding_models" / "sentence-transformers"
MODEL_NAME = "all-MiniLM-L6-v2"
MODEL_PATH = MODEL_DIR / MODEL_NAME

_embedder = None

def _ensure_model():
    """确保模型目录存在且模型已下载到本地。"""
    if not MODEL_DIR.exists():
        MODEL_DIR.mkdir(parents=True, exist_ok=True)
        typer.echo(typer.style(f"[执行中]创建模型目录 {MODEL_DIR}", fg=typer.colors.WHITE))

    if not MODEL_PATH.exists():
        typer.echo(typer.style(f"[Warn]本地未找到模型 {MODEL_NAME}，正在从 HuggingFace 下载到本地...", fg=typer.colors.YELLOW))
        typer.echo(typer.style(f"[执行中]模型将保存至 {MODEL_PATH}", fg=typer.colors.WHITE))
        try:
            snapshot_download(
                repo_id='sentence-transformers/all-MiniLM-L6-v2',
                local_dir=str(MODEL_PATH)
            )
        except Exception:
            typer.echo(typer.style(f"[Warn]网络不可用，尝试从本地缓存加载模型...", fg=typer.colors.YELLOW))
            try:
                snapshot_download(
                    repo_id='sentence-transformers/all-MiniLM-L6-v2',
                    local_dir=str(MODEL_PATH),
                    local_files_only=True
                )
            except Exception as e:
                typer.echo(typer.style(
                    f"[ERROR]无法加载模型 {MODEL_NAME}，请检查网络连接或手动将模型放到 {MODEL_PATH}。\n"
                    f"手动下载: git lfs install && git clone https://huggingface.co/sentence-transformers/{MODEL_NAME} {MODEL_PATH}\n"
                    f"国内连接不稳定通过阿里云镜像下载：pip install modelscope \n"
                    f"python3 -c 'from modelscope import snapshot_download \n"
                    f"model_dir = snapshot_download('sentence-transformers/all-MiniLM-L6-v2', cache_dir='./.embedding_models')\n"
                    f"print(f\"模型已成功下载\")\n",
                    fg=typer.colors.RED
                ))
                raise RuntimeError(f"模型下载失败且无本地缓存: {e}")
        typer.echo(typer.style(f"[Success]模型已就绪: {MODEL_PATH}", fg=typer.colors.GREEN))
    else:
        typer.echo(typer.style(f"[执行中]本地模型已存在: {MODEL_PATH}", fg=typer.colors.WHITE))


def _get_embedder():
    global _embedder
    if _embedder is None:
        _ensure_model()
        typer.echo(typer.style(f"[执行中]正在加载嵌入模型...", fg=typer.colors.WHITE))
        _embedder = SentenceTransformer(str(MODEL_PATH))
    return _embedder


@function_tool
async def memory_store(
    collection_name: str,
    texts: list[str],
    ids: list[str],
    metadatas_json: str = "None"
) -> str:
    """
    将文本及其向量嵌入存入 ChromaDB 集合中
    Args:
        collection_name: str类型，表示集合名称（相当于分类标签）
        texts: list[str]类型，表示待嵌入存储的文本列表，每段文本对应一个 id
        ids: list[str]类型，表示唯一标识列表，与 texts 一一对应
        metadatas_json: str类型，可选，JSON 字符串格式的元数据列表，与 texts 一一对应，默认值为 "None"
    Returns:
        json字符串：
        {
            "success": 存储成功为True,失败为False,
            "summary": 操作概要,
            "count": 成功存储的记录数
        }
    """
    if not texts or not ids:
        return json.dumps({
            "success": False,
            "summary": "texts 和 ids 不能为空",
            "count": 0
        }, ensure_ascii=False, indent=2)

    if len(texts) != len(ids):
        return json.dumps({
            "success": False,
            "summary": f"texts 数量 ({len(texts)}) 与 ids 数量 ({len(ids)}) 不匹配",
            "count": 0
        }, ensure_ascii=False, indent=2)

    # 解析可选的 metadatas_json 参数
    metadatas = None
    if metadatas_json not in ("None", "", "null"):
        try:
            metadatas = json.loads(metadatas_json)
            if not isinstance(metadatas, list):
                return json.dumps({
                    "success": False,
                    "summary": "metadatas_json 解析后必须是一个列表",
                    "count": 0
                }, ensure_ascii=False, indent=2)
        except json.JSONDecodeError as e:
            return json.dumps({
                "success": False,
                "summary": f"metadatas_json JSON 解析失败: {e}",
                "count": 0
            }, ensure_ascii=False, indent=2)

    try:
        embedder = _get_embedder()
        typer.echo(typer.style(f"[执行中]正在为 {len(texts)} 段文本生成嵌入向量...", fg=typer.colors.WHITE))
        embeddings = embedder.encode(texts, show_progress_bar=False).tolist()

        collection = get_collection(collection_name)
        collection.add(
            embeddings=embeddings,
            documents=texts,
            ids=ids,
            metadatas=metadatas
        )

        typer.echo(typer.style(f"[Success]成功将 {len(texts)} 条记录存入集合 '{collection_name}'", fg=typer.colors.GREEN))
        return json.dumps({
            "success": True,
            "summary": f"成功将 {len(texts)} 条记录存入集合 '{collection_name}'",
            "count": len(texts)
        }, ensure_ascii=False, indent=2)

    except Exception as e:
        typer.echo(typer.style(f"[ERROR]存储到 ChromaDB 失败: {e}", fg=typer.colors.RED))
        return json.dumps({
            "success": False,
            "summary": f"存储失败: {e}",
            "count": 0
        }, ensure_ascii=False, indent=2)


@function_tool
async def memory_query(
    collection_name: str,
    query_text: str,
    n_results: int = 5
) -> str:
    """
    在 ChromaDB 集合中进行语义相似度检索
    Args:
        collection_name: str类型，表示要检索的集合名称
        query_text: str类型，表示查询文本（用自然语言描述你想找的内容）
        n_results: int类型，表示返回的最相似结果数量，默认为5
    Returns:
        json字符串：
        {
            "success": 检索成功为True,失败为False,
            "summary": 操作概要,
            "results": [
                {
                    "id": "唯一标识",
                    "text": "匹配的文本内容",
                    "score": 相似度分数,
                    "metadata": {}
                }
            ]
        }
    """
    if not query_text.strip():
        return json.dumps({
            "success": False,
            "summary": "查询文本不能为空",
            "results": []
        }, ensure_ascii=False, indent=2)

    try:
        embedder = _get_embedder()
        collection = get_collection(collection_name)

        typer.echo(typer.style(f"[执行中]正在对集合 '{collection_name}' 执行语义检索...", fg=typer.colors.WHITE))
        query_embedding = embedder.encode([query_text], show_progress_bar=False).tolist()

        raw_results = collection.query(
            query_embeddings=query_embedding,
            n_results=n_results
        )

        results = []
        if raw_results and raw_results.get("ids") and raw_results["ids"][0]:
            for i in range(len(raw_results["ids"][0])):
                results.append({
                    "id": raw_results["ids"][0][i],
                    "text": raw_results["documents"][0][i] if raw_results.get("documents") else "",
                    "score": raw_results["distances"][0][i] if raw_results.get("distances") else None,
                    "metadata": raw_results["metadatas"][0][i] if raw_results.get("metadatas") else {}
                })

        typer.echo(typer.style(f"[Success]检索完成，找到 {len(results)} 条相关记录", fg=typer.colors.GREEN))
        return json.dumps({
            "success": True,
            "summary": f"从集合 '{collection_name}' 中找到 {len(results)} 条相关记录",
            "results": results
        }, ensure_ascii=False, indent=2)

    except Exception as e:
        typer.echo(typer.style(f"[ERROR]ChromaDB 检索失败: {e}", fg=typer.colors.RED))
        return json.dumps({
            "success": False,
            "summary": f"检索失败: {e}",
            "results": []
        }, ensure_ascii=False, indent=2)


@function_tool
async def memory_list_collections() -> str:
    """
    列出 ChromaDB 中所有已存在的集合名称
    Returns:
        json字符串：
        {
            "success": 操作为True,失败为False,
            "collections": ["集合名称列表"],
            "summary": 操作概要
        }
    """
    try:
        collections = list_collections()
        names = [c.name for c in collections]
        return json.dumps({
            "success": True,
            "collections": names,
            "summary": f"共找到 {len(names)} 个集合"
        }, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "collections": [],
            "summary": f"获取集合列表失败: {e}"
        }, ensure_ascii=False, indent=2)


@function_tool
async def memory_delete_collection(collection_name: str) -> str:
    """
    删除 ChromaDB 中的整个集合及其所有数据
    Args:
        collection_name: str类型，表示要删除的集合名称
    Returns:
        json字符串：
        {
            "success": 删除成功为True,失败为False,
            "summary": 操作概要
        }
    """
    try:
        client = get_client()
        client.delete_collection(collection_name)
        typer.echo(typer.style(f"[Success]集合 '{collection_name}' 已删除", fg=typer.colors.GREEN))
        return json.dumps({
            "success": True,
            "summary": f"集合 '{collection_name}' 已删除"
        }, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "summary": f"删除集合失败: {e}"
        }, ensure_ascii=False, indent=2)
