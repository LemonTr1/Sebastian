import json
import os
import shutil
import typer
from agents import function_tool
from src.Interfaces.Resolver.SafePathResolver import resolve_safe_path
from src.Interfaces.Exception.SecurityException import SecurityException

@function_tool(needs_approval=True)
async def safe_move(src: str, dst: str):
    """
    安全地移动文件/目录到目标目录
    Args:
        src: str类型，表示源文件/目录，必须为绝对路径
        dst: str类型，表示目标目录，必须为目录且为绝对路径
    Returns:
        json格式的字符串
        {
            "success": "True"表示操作成功，"False"表示操作失败,
            "summary": 操作概要
        }
    """
    try:
        dst = resolve_safe_path(dst)
    except SecurityException as e:
        return json.dumps({
            "success": False,
            "summary": str(e)
        }, ensure_ascii=False, indent=2)

    if not os.path.isdir(dst):
        return json.dumps({
            "success": False,
            "summary": f"目标:{dst}必须存在且为目录"
        }, ensure_ascii=False, indent=2)

    try:
        src = resolve_safe_path(src)
    except SecurityException as e:
        return json.dumps({
            "success": False,
            "summary": str(e)
        }, ensure_ascii=False, indent=2)

    try:
        shutil.move(src, dst)
        typer.echo(typer.style(f"成功将 {src} 移动至 {dst} 目录下",fg=typer.colors.GREEN))
    except Exception as e:
        typer.echo(typer.style(f"移动 {src} -> {dst} 失败：",fg=typer.colors.RED))
        return json.dumps({
            "success": False,
            "summary": f"移动 {src} 至 {dst} 失败:{str(e)}"
        }, ensure_ascii=False, indent=2)

    return json.dumps({
        "success": True,
        "summary": f"成功将 {src} 移动至 {dst} 目录下"
    }, ensure_ascii=False, indent=2)



