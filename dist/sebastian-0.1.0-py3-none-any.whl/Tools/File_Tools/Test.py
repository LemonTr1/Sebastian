import os
import typer
from agents import function_tool
import json

from src.Interfaces.Exception.SecurityException import SecurityException
from src.Interfaces.Resolver.SafePathResolver import resolve_safe_path


#判断是否存在目标文件/目录
@function_tool
async def which(path: str)->str:
    """
    判断目标文件/目录的路径是否存在
    Args:
        path: str类型，表示目标文件/目录的绝对路径
    Returns:
        json格式字符串
        {
            "exist": "True"表示存在，"False"表示不存在
            "path": 表示目标文件/目录的绝对路径
            "error": 错误信息
        }
    """
    try:
        path = resolve_safe_path(path, "real")
    except SecurityException as e:
        return json.dumps({
            "exist": False,
            "path": None,
            "error": str(e)
        }, ensure_ascii=False, indent=2)
    typer.echo(typer.style(f"[执行中]正在执行：test {path}", fg=typer.colors.WHITE))
    if os.path.exists(path):
        return json.dumps({
            "exist": True,
            "path": path,
            "error": None
        }, ensure_ascii=False, indent=2)
    return json.dumps({
        "exist": False,
        "path": None,
        "error": "该路径不存在"
    }, ensure_ascii=False, indent=2)