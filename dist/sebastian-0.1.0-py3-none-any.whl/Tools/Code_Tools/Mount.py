import os
import typer
from agents import function_tool
from pathlib import Path
import json
import subprocess

HOME = "/workspace"
IMAGE_NAME = "sebastian:local"

def copy_from_latest_container(image_name: str, src: str, dst: str):
    # 获取基于该镜像的最新容器ID
    result = subprocess.run(
        ["docker", "ps", "-aql", "-f", f"ancestor={image_name}"],
        capture_output=True, text=True, check=True
    )
    container_id = result.stdout.strip().split("\n")[0]

    if not container_id:
        raise RuntimeError(f"没有找到基于镜像 {image_name} 的容器")

    # 正确：用容器ID，不是镜像名
    subprocess.run([
        "docker", "cp",
        f"{container_id}:{src}",
        dst
    ], check=True)

@function_tool(needs_approval=True)
def mount(src: str, dst: str)->str:
    """
    将沙箱内文件挂载到上级Agent所在运行环境中的挂载点
    Args:
        src: str类型，表示沙箱内的源文件路径，必须为绝对路径
        dst: str类型，表示挂载点路径，必须为绝对路径
    Returns:
        json类型的字符串
        {
            "success": "True"表示挂载成功，"False"表示失败,
            "summary": 操作概要
        }
    """
    dst = os.path.abspath(dst)
    if not Path(dst).is_relative_to(Path.home()):
        return json.dumps({
            "success": False,
            "summary": f"挂载点必须为基于上级Agent运行环境的{str(Path.home())}目录的绝对路径"
        }, ensure_ascii=False, indent=2)

    if not Path(src).is_relative_to(Path(HOME)):
        return json.dumps({
            "success": False,
            "summary": f"源文件必须为基于沙箱内环境的{HOME}目录的绝对路径"
        }, ensure_ascii=False, indent=2)

    try:
        typer.echo(typer.style(f"[执行中]正在将产出文件挂载到{dst}", fg=typer.colors.WHITE))
        copy_from_latest_container(IMAGE_NAME, src, dst)

        typer.echo(typer.style(f"[Success]已成功挂载到{dst}中",fg=typer.colors.GREEN))
        return json.dumps({
            "success": True,
            "summary": f"成功挂载到{dst}中"
        }, ensure_ascii=False, indent=2)
    except RuntimeError as e:
        typer.echo(typer.style(str(e), fg=typer.colors.RED))
        return json.dumps({
            "success": False,
            "summary": str(e)
        }, ensure_ascii=False, indent=2)
    except subprocess.CalledProcessError as e:
        typer.echo(typer.style(f"挂载操作失败:{str(e)}",fg=typer.colors.RED))
        return json.dumps({
            "success": False,
            "summary": f"挂载失败：{str(e)}"
        }, ensure_ascii=False, indent=2)
    except Exception as e:
        typer.echo(typer.style(f"挂载出现错误：{str(e)}",fg=typer.colors.RED))
        return json.dumps({
            "success": False,
            "summary": f"发生错误：{str(e)}"
        }, ensure_ascii=False, indent=2)



