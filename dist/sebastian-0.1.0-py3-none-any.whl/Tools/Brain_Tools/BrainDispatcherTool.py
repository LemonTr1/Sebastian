from pathlib import Path
import typer
from agents import function_tool
from typing import Literal, List
from src.Interfaces.Exception.SecurityException import SecurityException
from src.Interfaces.Resolver.SafePathResolver import resolve_safe_path
from src.Modules.CodeModules.CodeAgentGateway import code_agent_tool
from src.Modules.WebModules.WebAgentGateway import web_agent_tool
from src.Modules.FileModules.FileAgentGateway import file_agent_tool
from src.Modules.MemoryModules.MemoryAgentGateway import memory_agent_tool
import json

HOME = str(Path.home())

@function_tool
async def dispatcher(command: str, type: Literal["File", "Code", "Web", "Memory"], only_path: str = "None")->str:
    """
    路由分配工具，将命令分发到 File/Code/Web/Memory 子Agent执行。
    Args:
        command: 自然语言描述的最小可执行步骤
        type: 操作类型
        only_path: 仅 Code 操作时填写要执行的具体代码文件/项目目录的绝对路径，用于沙箱挂载，禁止直接挂载用户家目录或桌面目录
    Returns:
        JSON字符串，字段：success, tool_id, summary, data, need_confirmed
    """
    if "~/" in command or "/.." in command:
        return json.dumps({
            "success": False,
            "tool_id": None,
            "summary": "请解析路径中的'~'或'..'，规范化为绝对路径",
            "data": None,
            "need_confirmed": False,
        }, ensure_ascii=False, indent=2)

    if ("/" in command and HOME not in command) or ("//" in command):
        return json.dumps({
            "success": False,
            "tool_id": None,
            "summary": f"路径必须规范化为基于当前用户家目录：{HOME}的绝对路径",
            "data": None,
            "need_confirmed": False,
        }, ensure_ascii=False, indent=2)

    typer.echo(typer.style(f"\n[Enter]路由：{type}，命令:{command[:80]}...，路径参数：{only_path}", fg=typer.colors.WHITE))
    if (type == "File" or type == "Web" or type == "Memory") and only_path != "None":
        return json.dumps({
            "success": False,
            "tool_id": None,
            "summary": "只有'Code'操作才可以填写only_path参数",
            "data": None,
            "need_confirmed": False,
        }, ensure_ascii=False, indent=2)
    if only_path != "None":
        try:
            only_path = resolve_safe_path(only_path, "real")
        except SecurityException as e:
            return json.dumps({
                "success": False,
                "tool_id": None,
                "summary": f"文件路径不存在或不合法：{str(e)}，已拦截该指令",
                "data": None,
                "need_confirmed": False,
            }, ensure_ascii=False, indent=2)
    if type == "File":
        result = await file_agent_tool(command)
    elif type == "Code":
        result = await code_agent_tool(command, only_path)
    elif type == "Web":
        result = await web_agent_tool(command)
    elif type == "Memory":
        result = await memory_agent_tool(command)
    else:
        return json.dumps({
            "success": False,
            "tool_id": None,
            "summary": "操作类型必须是File，Code，Web，Memory的其中一个",
            "data": None,
            "need_confirmed": False,
        }, ensure_ascii=False, indent=2)
    return result
