import shlex
import shutil
import subprocess
import json
import typer
from agents import function_tool


@function_tool
async def opencli_command(description: str, command: str) -> str:
    """
    通过 OpenCLI 操作浏览器（浏览器控制）。
    前置条件：Chrome 已打开且 Browser Bridge 扩展已激活，否则操作将会失败。

    Args:
        description: str类型，说明即将进行的浏览器操作简述
        command: str类型，完整的 opencli 命令（必须以 "opencli browser" 开头）
    Returns:
        json字符串:
        {
            "success": "True"表示操作成功，"False"表示操作失败,
            "summary": 操作概要,
            "data": opencli命令返回的输出,
            "url": 执行命令后当前页面的URL,
        }
    """
    # 1. 检查 opencli 是否已安装
    if not shutil.which("opencli"):
        return json.dumps({
            "success": False,
            "summary": "OpenCLI 未安装或不在 PATH 中，无法控制浏览器",
            "data": None,
            "url": None
        }, ensure_ascii=False, indent=2)

    # 2. 安全分割命令
    try:
        args = shlex.split(command)
    except ValueError as e:
        return json.dumps({
            "success": False,
            "summary": f"命令格式错误（引号不匹配等）：{e}",
            "data": None,
            "url": None
        }, ensure_ascii=False, indent=2)

    # 3. 校验必须为 "opencli browser" 前缀
    if len(args) < 2 or args[0] != "opencli" or args[1] != "browser":
        return json.dumps({
            "success": False,
            "summary": "命令必须以 'opencli browser' 开头",
            "data": None,
            "url": None
        }, ensure_ascii=False, indent=2)

    # 4. session 名合法性检查（args[2] = session 名）
    if len(args) < 3:
        return json.dumps({
            "success": False,
            "summary": "命令缺少 session 名称，格式: opencli browser <session> <action> [args]",
            "data": None,
            "url": None
        }, ensure_ascii=False, indent=2)

    session = args[2]
    allowed_session_chars = set("abcdefghijklmnopqrstuvwxyz0123456789_-")
    if not all(c in allowed_session_chars for c in session):
        return json.dumps({
            "success": False,
            "summary": f"Session 名称 '{session}' 包含不合法字符（仅允许小写字母、数字、下划线和连字符）",
            "data": None,
            "url": None
        }, ensure_ascii=False, indent=2)

    typer.echo(typer.style(f"[执行中]{description}: {command}", fg=typer.colors.WHITE))

    # 5. 禁止所有可能导致新建标签页的操作
    action = args[3] if len(args) > 3 else ""

    # 禁止 tab new
    if action == "tab" and len(args) >= 5:
        if args[4] == "new":
            return json.dumps({
                "success": False,
                "summary": "不允许新建标签页，所有操作应在当前标签页内完成",
                "data": None,
                "url": None
            }, ensure_ascii=False, indent=2)
        if args[4] not in ("list", "select"):
            return json.dumps({
                "success": False,
                "summary": f"不支持的 tab 操作 '{args[4]}'，仅允许 list 和 select",
                "data": None,
                "url": None
            }, ensure_ascii=False, indent=2)

    # 禁止 open（一定会新建标签页），必须改用 eval 做当前标签页跳转
    if action == "open":
        target_url = " ".join(args[4:]) if len(args) >= 5 else ""
        hint = f"，请改用 eval: opencli browser {session} eval \"document.location.replace('{target_url}')\"" if target_url else ""
        return json.dumps({
            "success": False,
            "summary": f"'open' 操作会新建标签页，已被禁止{hint}",
            "data": None,
            "url": None
        }, ensure_ascii=False, indent=2)

    # 6. 将 keys Enter 替换为 eval 派发完整 KeyboardEvent（opencli 的 keys 不兼容现代 SPA）
    if action == "keys" and len(args) >= 5 and args[4] in ("Enter", "enter"):
        typer.echo(typer.style(f"[执行中]派发 Enter 按键事件", fg=typer.colors.WHITE))
        args = ["opencli", "browser", session, "eval",
                r"(function(){"
                r"'use strict';"
                r"document.querySelectorAll('[target]').forEach(e=>e.removeAttribute('target'));"
                r"window.open=function(){return null;};"
                r"Window.prototype.open=function(){return null;};"
                r"const e=document.activeElement;"
                r"if(!e)return;"
                r"['keydown','keypress','keyup'].forEach(t=>{"
                r"e.dispatchEvent(new KeyboardEvent(t,{key:'Enter',code:'Enter',keyCode:13,which:13,"
                r"bubbles:true,cancelable:true}))"
                r"});"
                r"if(e.form){e.form.target='_self';try{e.form.requestSubmit()}catch(ex){e.form.submit()}}"
                r"})()"]
        action = "eval"

    # 7. 对于 click 操作，先注入防护防止开新标签页
    if action == "click":
        strip_result = subprocess.run(
            ["opencli", "browser", session, "eval",
             # 清除所有 target=_blank + 覆写 window.open 为无操作
             r"(function(){"
             r"'use strict';"
             r"document.querySelectorAll('[target]').forEach(e=>e.removeAttribute('target'));"
             r"window.open=function(){return null;};"
             r"Window.prototype.open=function(){return null;};"
             r"})()"],
            capture_output=True,
            text=True,
            timeout=10
        )
        strip_stderr = (strip_result.stderr or "")
        strip_stdout = (strip_result.stdout or "")
        if strip_result.returncode != 0 and "BROWSER_CONNECT" in (strip_stderr + strip_stdout):
            return json.dumps({
                "success": False,
                "summary": "浏览器未连接，请确保 Chrome 已打开且 Browser Bridge 扩展已激活",
                "data": None,
                "url": None
            }, ensure_ascii=False, indent=2)

    # 7. 根据命令类型决定超时
    if action in ("state", "screenshot", "eval"):
        cmd_timeout = 60
    else:
        cmd_timeout = 15

    # 8. 执行命令（直接运行，已经包含 opencli browser 前缀）
    try:
        result = subprocess.run(
            args,  # args 已经是完整的 ["opencli", "browser", ...]
            capture_output=True,
            text=True,
            timeout=cmd_timeout
        )

        stdout = (result.stdout or "").strip()
        stderr = (result.stderr or "").strip()

        if result.returncode != 0:
            # 特殊识别浏览器未连接错误
            summary = f"命令: {command} 失败，返回码: {result.returncode}"
            if "BROWSER_CONNECT" in (stderr + stdout):
                summary += "（浏览器未连接，请确保 Chrome 已打开且 Browser Bridge 扩展已激活）"
            elif "element not found" in (stdout + stderr).lower():
                summary += "（页面元素未找到，可能 DOM 已变化，请重新执行 state 获取最新状态）"
            elif "timeout" in (stderr + stdout).lower():
                summary += "（操作超时，可拆分命令或缩短等待时间）"

            typer.echo(typer.style(f"[ERROR]{summary}", fg=typer.colors.RED))
            return json.dumps({
                "success": False,
                "summary": summary,
                "data": stdout,
                "url": None,
                "stderr": stderr,
            }, ensure_ascii=False, indent=2)

        # 8. 执行成功后，尝试获取当前页面的 URL（仅对可能导致页面跳转的动作）
        current_url = None
        if action in ("click", "tab", "keys", "eval"):
            try:
                url_result = subprocess.run(
                    ["opencli", "browser", session, "eval", "window.location.href"],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if url_result.returncode == 0 and url_result.stdout.strip():
                    current_url = url_result.stdout.strip().strip('"').strip("'")
            except (subprocess.TimeoutExpired, subprocess.SubprocessError):
                pass

        response = {
            "success": True,
            "summary": f"执行命令：{command} 成功",
            "data": stdout,
            "url": current_url
        }
        # 如果 stderr 有内容（非错误），附带上供 Agent 参考
        if stderr:
            response["stderr"] = stderr

        return json.dumps(response, ensure_ascii=False, indent=2)

    except subprocess.TimeoutExpired as e:
        timeout_summary = f"命令: {command} 执行超时（{cmd_timeout}s）"
        timeout_stdout = (e.stdout or b"").decode("utf-8", errors="replace").strip() if e.stdout else ""
        timeout_stderr = (e.stderr or b"").decode("utf-8", errors="replace").strip() if e.stderr else ""
        typer.echo(typer.style(f"[ERROR]{timeout_summary}", fg=typer.colors.RED))
        return json.dumps({
            "success": False,
            "summary": timeout_summary,
            "data": timeout_stdout or None,
            "url": None
        }, ensure_ascii=False, indent=2)
