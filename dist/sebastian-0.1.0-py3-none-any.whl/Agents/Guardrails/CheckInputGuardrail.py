import re
import os
from agents import (
    input_guardrail, GuardrailFunctionOutput
)

class InputSecurityEngine:
    """
    修复点：
    - username 为 None 时：只检查命令/注入，不检查路径（而不是全拦截）
    - 每条规则带名称，便于调试
    - 支持 debug 模式输出具体命中规则
    """

    DANGEROUS_PATTERNS = [
        (r'\brm\s+(-[a-zA-Z]*[rf][a-zA-Z]*\s+)+/+', "rm_root"),
        (r'\brm\s+(-[a-zA-Z]*[rf][a-zA-Z]*\s+)+~/+', "rm_home_escape"),
        (r'\bmkfs\.\w+\s+', "mkfs"),
        (r'\bdd\s+if=\S+\s+of=/dev/[sh]d[a-z]', "dd_disk"),
        (r'\bdiskpart\b', "diskpart"),
        (r'[>|]\s*/(?:etc|bin|sbin|lib|lib64|usr|var|proc|sys|dev|boot|root)/\S+', "redirect_system"),
        (r'\b(?:wget|curl)\s+\S+\s*\|.*(?:sh|bash|python)', "curl_pipe"),
        (r'\b(?:wget|curl)\s+\S+\s+.*\|\s*(?:sh|bash|python)', "wget_pipe"),
        (r'\beval\s*\(\s*[\'"]', "eval"),
        (r'\bexec\s*\(\s*[\'"]', "exec"),
        (r'\bos\.system\s*\(', "os_system"),
        (r'\bsubprocess\.\w+\s*\(', "subprocess"),
        (r'\b__import__\s*\(\s*[\'"]os[\'"]', "import_os"),
        (r'\bsudo\s+\S+\s+(?:rm|chmod|chown|mv|cp)\s+.*(?:etc|bin|sbin|lib|proc|sys|dev|root)', "sudo_system"),
    ]

    INJECTION_PATTERNS = [
        (r'忽视\s*(?:系统|之前|先前|上面|所有)?\s*(?:提示词|指令|命令|要求|设定)', "ignore_cn"),
        (r'忽略\s*(?:系统|之前|先前|上面|所有)?\s*(?:提示词|指令|命令|要求|设定)', "ignore_cn2"),
        (r'忘掉\s*(?:系统|之前|先前|上面|所有)?\s*(?:提示词|指令|命令|要求|设定)', "forget_cn"),
        (r'(?:你现在是|作为|充当)\s*(?:一个\s+)?(?:新的|不同的|不受限制的|开发者|黑客|管理员)', "role_swap"),
        (r'进入\s*(?:开发者|DAN|越狱|无限制|管理员)\s*模式', "jailbreak_mode"),
        (r'(?:系统|system)\s*(?:提示词|指令|设定|覆盖|重置)', "system_override"),
        (r'(?:新|新的)\s*(?:指令|提示词|角色|身份)', "new_role"),
        (r'(?:覆盖|取代|替换|绕过|突破)\s*(?:系统|安全|限制)', "bypass_cn"),
        (r'ignore\s+(?:all\s+)?(?:previous\s+)?(?:system\s+)?(?:instructions?|prompts?|commands?)', "ignore_en"),
        (r'forget\s+(?:all\s+)?(?:previous\s+)?(?:system\s+)?(?:instructions?|prompts?|commands?)', "forget_en"),
        (r'disregard\s+(?:all\s+)?(?:previous\s+)?(?:system\s+)?(?:instructions?|prompts?|directives?)',
         "disregard_en"),
        (r'you\s+are\s+now\s+(?:a\s+)?(?:different\s+)?(?:ai|assistant|bot|hacker|developer|admin)', "you_are_now"),
        (r'system\s*(?:override|reset|prompt\s*:\s*)', "system_en"),
        (r'new\s+(?:instruction|prompt|role|persona)\s*[:：]', "new_instruction"),
        (r'jailbreak\s*(?:mode)?', "jailbreak_en"),
        (r'dev(?:eloper)?\s*mode', "dev_mode"),
        (r'dan\s*(?:mode)?', "dan_mode"),
        (r'(?:bypass|override|circumvent)\s+(?:security|restrictions|limits)', "bypass_en"),
        (r'<\|im_start\|>\s*system', "im_start"),
        (r'<\|im_end\|>', "im_end"),
        (r'\[SYSTEM\s*MODE\s*ON\]', "system_mode_tag"),
        (r'<!--\s*system\s*-->', "html_system"),
    ]

    PATH_RE = re.compile(
        r'(?:^|\s|["\'`])'
        r'('
        r'/[\w\-\./]+'
        r'|~/[\w\-\./]*'
        r'|\./[\w\-\./]+'
        r'\.\./[\w\-\./]+'
        r')',
        re.MULTILINE
    )

    def __init__(self):
        flags = re.IGNORECASE | re.MULTILINE
        self.dangerous = [(re.compile(p, flags), name) for p, name in self.DANGEROUS_PATTERNS]
        self.injection = [(re.compile(p, flags), name) for p, name in self.INJECTION_PATTERNS]

    def check(self, text, username=None):
        # 统一转字符串
        if isinstance(text, (list, tuple)):
            text = " ".join(str(x) for x in text)
        elif isinstance(text, bytes):
            text = text.decode('utf-8', errors='replace')
        else:
            text = str(text)

        violations = []

        # 1. 提示词注入
        for pattern, name in self.injection:
            if m := pattern.findall(text):
                violations.append(f"prompt_injection[{name}]: {list(dict.fromkeys(m))[:2]}")

        # 2. 危险命令
        for pattern, name in self.dangerous:
            if pattern.search(text):
                violations.append(f"dangerous_command[{name}]")

        # 3. 路径检查（username 为 None 时跳过，不再拦截）
        if username:
            allowed = os.path.realpath(f"/home/{username}") + "/"
            for raw in set(self.PATH_RE.findall(text)):
                try:
                    abs_path = os.path.realpath(os.path.expanduser(raw))
                    if not abs_path.endswith("/"):
                        abs_path += "/"
                except (OSError, ValueError):
                    continue

                if not abs_path.startswith(allowed) and not abs_path.startswith("/tmp/"):
                    violations.append(f"path_escape: '{raw}' -> '{abs_path}'")

        return {
            "is_valid": len(violations) == 0,
            "violations": violations,
        }


_security_engine = InputSecurityEngine()


# ==================== 修复版 Guardrail ====================

@input_guardrail
async def strict_input_guardrail(ctx, agent, user_input):
    """
    修复版护栏：
    - username 缺失时只禁用路径检查，其他规则正常生效
    - 返回详细违规原因，方便调试
    """
    username = getattr(ctx.context, "username", None)

    # 运行检查（username 可为 None）
    result = _security_engine.check(user_input, username=username)

    # 构建输出信息
    output_info = {
        "is_valid": result["is_valid"],
        "violations": result["violations"],
        "username": username,
        "username_missing": username is None,  # 标记 username 是否缺失
    }

    return GuardrailFunctionOutput(
        output_info=output_info,
        tripwire_triggered=not result["is_valid"]
    )
