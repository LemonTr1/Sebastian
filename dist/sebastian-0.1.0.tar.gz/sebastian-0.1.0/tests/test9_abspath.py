import os

def main():
    print(os.path.abspath("~/桌面"))

if __name__ == '__main__':
    main()