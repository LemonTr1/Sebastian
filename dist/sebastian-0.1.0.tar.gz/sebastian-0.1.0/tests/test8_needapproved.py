import asyncio
import json
from src.Models.models import get_model
from agents import Agent, Runner, function_tool

@function_tool(needs_approval=True)
async def query_weather(city: str, time: str):
    """
    查询天气
    :param city: str类型，表示城市
    :param time: str类型，表示日期
    :return: 字符串，表示该城市的天气
    """
    return f"今天:{time} {city}天气为晴天"

agent = Agent(
    name="agent",
    model=get_model(),
    instructions="使用提供的工具查询天气",
    tools=[query_weather]
)

async def main():
    question = input()
    result = await Runner.run(agent, question)
    while result.interruptions:
        state = result.to_state()
        for interruption in result.interruptions:
            print(interruption.name)
            args = interruption.arguments
            print(args)
            args = json.loads(args)
            print(args.get("city"))
            print(args.get("time"))
            state.approve(interruption, always_approve=False)

        result = await Runner.run(agent, state)

    print(result.final_output)

if __name__ == "__main__":
    asyncio.run(main())